import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../models/transfer_task.dart';

class TransferProvider extends ChangeNotifier {
  final List<TransferTask> _tasks = [];
  List<TransferTask> get tasks => List.unmodifiable(_tasks);

  String createSendTask(String fileName, int fileSize, String peerName) {
    final task = TransferTask(
      id: const Uuid().v4(),
      fileName: fileName,
      fileSize: fileSize,
      direction: TransferDirection.send,
      peerName: peerName,
      status: TransferStatus.transferring,
    );
    _tasks.insert(0, task);
    notifyListeners();
    return task.id;
  }

  void createReceiveTask(String taskId, String fileName, int fileSize, String peerName) {
    final task = TransferTask(
      id: taskId,
      fileName: fileName,
      fileSize: fileSize,
      direction: TransferDirection.receive,
      peerName: peerName,
      status: TransferStatus.transferring,
    );
    _tasks.insert(0, task);
    notifyListeners();
  }

  void updateProgress(String taskId, int transferredBytes) {
    final task = _find(taskId);
    if (task == null) return;
    task.transferredBytes = transferredBytes;
    notifyListeners();
  }

  void completeTask(String taskId) {
    final task = _find(taskId);
    if (task == null) return;
    task.status = TransferStatus.completed;
    if (task.fileSize > 0) task.transferredBytes = task.fileSize;
    notifyListeners();
  }

  void failTask(String taskId, String error) {
    final task = _find(taskId);
    if (task == null) return;
    task.status = TransferStatus.failed;
    task.errorMessage = error;
    notifyListeners();
  }

  TransferTask? _find(String id) {
    for (final t in _tasks) {
      if (t.id == id) return t;
    }
    return null;
  }

  void clearCompleted() {
    _tasks.removeWhere((t) => !t.isActive);
    notifyListeners();
  }
}