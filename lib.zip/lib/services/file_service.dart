import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';

class FileService {
  Future<List<File>> pickFiles() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      withData: false,
      withReadStream: true,
    );
    if (result == null) return const [];

    final files = <File>[];
    for (final picked in result.files) {
      if (picked.path != null) {
        files.add(File(picked.path!));
        continue;
      }
      final stream = picked.readStream;
      if (stream == null) continue;
      final tmp = await getTemporaryDirectory();
      final file = File('${tmp.path}/${picked.name}');
      final sink = file.openWrite();
      await stream.pipe(sink);
      files.add(file);
    }
    return files;
  }

  Future<Directory> saveDirectory() async {
    if (Platform.isAndroid) {
      final external = await getExternalStorageDirectory();
      if (external != null) {
        final dir = Directory('${external.path}/Download');
        if (!await dir.exists()) await dir.create(recursive: true);
        return dir;
      }
    }
    final downloads = await getDownloadsDirectory();
    if (downloads != null) return downloads;
    return getApplicationDocumentsDirectory();
  }

  Future<String> uniquePath(String dir, String name) async {
    var candidate = '$dir/$name';
    if (!await File(candidate).exists()) return candidate;
    final dot = name.lastIndexOf('.');
    final base = dot > 0 ? name.substring(0, dot) : name;
    final ext = dot > 0 ? name.substring(dot) : '';
    var i = 1;
    while (await File('$dir/$base ($i)$ext').exists()) {
      i++;
    }
    return '$dir/$base ($i)$ext';
  }
}